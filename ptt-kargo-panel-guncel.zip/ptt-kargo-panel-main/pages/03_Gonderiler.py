import io
from datetime import datetime

import pandas as pd
import streamlit as st
from reportlab.graphics.barcode import code128
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas

from database.database import SessionLocal, engine
from database.models import Base, Shipment

Base.metadata.create_all(bind=engine)

st.title("Gönderiler")

db = SessionLocal()

if "selected_shipments" not in st.session_state:
    st.session_state.selected_shipments = []

if "pdf_bytes" not in st.session_state:
    st.session_state.pdf_bytes = None

if "pdf_name" not in st.session_state:
    st.session_state.pdf_name = "etiketler.pdf"


def safe(value):
    if value is None:
        return ""
    return str(value)


def short(value, limit):
    text = safe(value)
    if len(text) <= limit:
        return text
    return text[: limit - 2] + ".."


def excel_bytes(shipments):
    rows = []

    for item in shipments:
        rows.append(
            {
                "A": "",
                "B": safe(item.recipient_name),
                "C": safe(item.address),
                "D": safe(item.district),
                "E": safe(item.city),
                "F": item.weight or 0,
                "G": safe(item.phone),
                "H": "",
                "I": safe(item.product_name),
                "J": "",
                "K": "",
                "L": safe(item.tracking_number or item.barcode),
                "M": "",
                "N": "",
                "O": "",
                "P": "",
                "Q": "",
                "R": "",
                "S": item.width or 0,
                "T": item.length or 0,
                "U": item.height or 0,
            }
        )

    output = io.BytesIO()
    df = pd.DataFrame(rows, columns=list("ABCDEFGHIJKLMNOPQRSTU"))

    with pd.ExcelWriter(output, engine="xlsxwriter") as writer:
        df.to_excel(writer, index=False, header=False, sheet_name="Gönderiler")
        worksheet = writer.sheets["Gönderiler"]
        worksheet.set_column("A:A", 5)
        worksheet.set_column("B:B", 35)
        worksheet.set_column("C:C", 50)
        worksheet.set_column("D:E", 18)
        worksheet.set_column("F:F", 12)
        worksheet.set_column("G:G", 18)
        worksheet.set_column("I:I", 28)
        worksheet.set_column("L:L", 22)
        worksheet.set_column("S:U", 12)

    output.seek(0)
    return output.getvalue()


def draw_label(c, item):
    page_w = 40 * mm
    page_h = 50 * mm
    m = 1.5 * mm

    c.setLineWidth(0.35)
    c.rect(m, m, page_w - 2 * m, page_h - 2 * m)

    y = page_h - 4 * mm
    c.setFont("Helvetica-Bold", 5.5)
    c.drawCentredString(page_w / 2, y, "PTT GENEL MÜDÜRLÜĞÜ")
    c.drawCentredString(page_w / 2, y - 2.7 * mm, "KARGO ETİKETİ")

    top = page_h - 9 * mm
    c.line(m, top, page_w - m, top)

    sender_h = 8 * mm
    left_w = 25 * mm
    c.rect(m, top - sender_h, left_w, sender_h)
    c.rect(m + left_w, top - sender_h, page_w - 2 * m - left_w, sender_h)

    c.setFont("Helvetica-Bold", 3.9)
    c.drawString(m + 1 * mm, top - 2.2 * mm, "GÖNDERİCİ")
    c.setFont("Helvetica", 3.4)
    c.drawString(m + 1 * mm, top - 4.2 * mm, "Ziraat Katılım Bankası A.Ş.")
    c.drawString(m + 1 * mm, top - 6.1 * mm, "Hadımköy Lojistik Merkezi")

    c.setFont("Helvetica-Bold", 3.9)
    c.drawString(m + left_w + 1 * mm, top - 2.2 * mm, "PTT KABUL")
    c.setFont("Helvetica", 3.5)
    c.drawString(m + left_w + 1 * mm, top - 4.5 * mm, "MERKEZİ")

    alici_top = top - sender_h
    alici_h = 12 * mm
    c.rect(m, alici_top - alici_h, page_w - 2 * m, alici_h)
    c.setFont("Helvetica-Bold", 4.0)
    c.drawString(m + 1 * mm, alici_top - 2.4 * mm, "ALICI")
    c.setFont("Helvetica-Bold", 4.4)
    c.drawString(m + 1 * mm, alici_top - 4.8 * mm, short(item.recipient_name, 34))
    c.setFont("Helvetica", 3.5)
    c.drawString(m + 1 * mm, alici_top - 7.2 * mm, short(item.address, 45))
    c.drawString(m + 1 * mm, alici_top - 9.6 * mm, short(f"{safe(item.district)} / {safe(item.city)}", 45))

    info_top = alici_top - alici_h
    info_h = 6.5 * mm
    box_w = (page_w - 2 * m) / 4
    labels = ["TARİH", "ÖLÇÜ", "AĞIRLIK", "ŞUBE"]
    values = [
        datetime.now().strftime("%d.%m.%Y"),
        f"{item.width or 0:g}x{item.length or 0:g}x{item.height or 0:g}",
        f"{item.weight or 0:g} gr",
        safe(item.branch_code),
    ]

    for i in range(4):
        x = m + i * box_w
        c.rect(x, info_top - info_h, box_w, info_h)
        c.setFont("Helvetica-Bold", 3.2)
        c.drawCentredString(x + box_w / 2, info_top - 2.1 * mm, labels[i])
        c.setFont("Helvetica", 3.2)
        c.drawCentredString(x + box_w / 2, info_top - 4.7 * mm, short(values[i], 12))

    product_top = info_top - info_h
    product_h = 6.5 * mm
    c.rect(m, product_top - product_h, page_w - 2 * m, product_h)
    c.setFont("Helvetica-Bold", 3.7)
    c.drawString(m + 1 * mm, product_top - 2.2 * mm, "ÜRÜN İÇERİĞİ")
    c.setFont("Helvetica-Bold", 4.3)
    c.drawString(m + 1 * mm, product_top - 4.9 * mm, short(item.product_name, 38))

    barcode_top = product_top - product_h
    barcode_h = barcode_top - m
    c.rect(m, m, page_w - 2 * m, barcode_h)

    code_text = safe(item.tracking_number or item.barcode)
    b = code128.Code128(code_text, barHeight=9 * mm, barWidth=0.55)
    b_x = (page_w - b.width) / 2
    b_y = m + 5.4 * mm
    b.drawOn(c, b_x, b_y)

    c.setFont("Helvetica-Bold", 5.2)
    c.drawCentredString(page_w / 2, m + 2.4 * mm, code_text)


def pdf_bytes(shipments):
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=(40 * mm, 50 * mm))

    for item in shipments:
        draw_label(c, item)
        c.showPage()

    c.save()
    buffer.seek(0)
    return buffer.getvalue()


def get_selected_shipments():
    ids = st.session_state.selected_shipments
    if not ids:
        return []

    return (
        db.query(Shipment)
        .filter(Shipment.id.in_(ids))
        .order_by(Shipment.id.desc())
        .all()
    )


col1, col2, col3, col4 = st.columns(4)

with col1:
    filtre_alici = st.text_input("Alıcı Adı")

with col2:
    filtre_urun = st.text_input("Ürün İçeriği")

with col3:
    filtre_takip = st.text_input("Takip No")

with col4:
    filtre_durum = st.selectbox("Durum", ["Tümü", "Yazdırılmadı", "Yazdırıldı"])

query = db.query(Shipment).order_by(Shipment.id.desc())
gonderiler = query.all()

filtered = []

for item in gonderiler:
    if filtre_alici and filtre_alici.lower() not in safe(item.recipient_name).lower():
        continue

    if filtre_urun and filtre_urun.lower() not in safe(item.product_name).lower():
        continue

    if filtre_takip and filtre_takip.lower() not in safe(item.tracking_number).lower():
        continue

    if filtre_durum == "Yazdırılmadı" and item.is_printed:
        continue

    if filtre_durum == "Yazdırıldı" and not item.is_printed:
        continue

    filtered.append(item)

st.write(f"Toplam Kayıt: {len(filtered)}")

secili_ids = [item.id for item in filtered]

if st.checkbox("Tümünü Seç", key="tumunu_sec"):
    st.session_state.selected_shipments = secili_ids

st.divider()

h0, h1, h2, h3, h4, h5, h6, h7, h8 = st.columns([0.7, 1.5, 3, 3, 2.6, 2, 1.4, 1.4, 1.2])
h0.write("Seç")
h1.write("Durum")
h2.write("Alıcı Adı")
h3.write("Ürün İçeriği")
h4.write("Takip No")
h5.write("Kullanıcı")
h6.write("Detay")
h7.write("Yazdır")
h8.write("Sil")

for item in filtered:
    c0, c1, c2, c3, c4, c5, c6, c7, c8 = st.columns([0.7, 1.5, 3, 3, 2.6, 2, 1.4, 1.4, 1.2])

    with c0:
        checked = st.checkbox("", value=item.id in st.session_state.selected_shipments, key=f"sec_{item.id}")
        if checked and item.id not in st.session_state.selected_shipments:
            st.session_state.selected_shipments.append(item.id)
        if not checked and item.id in st.session_state.selected_shipments:
            st.session_state.selected_shipments.remove(item.id)

    with c1:
        if item.is_printed:
            st.error("Yazdırıldı")
        else:
            st.success("Yazdırılmadı")

    with c2:
        st.write(short(item.recipient_name, 34))

    with c3:
        st.write(short(item.product_name, 34))

    with c4:
        st.write(safe(item.tracking_number or item.barcode))

    with c5:
        st.write(safe(item.created_by))

    with c6:
        if st.button("Detay", key=f"detay_{item.id}"):
            st.session_state[f"show_{item.id}"] = not st.session_state.get(f"show_{item.id}", False)
            st.rerun()

    with c7:
        if st.button("Yazdır", key=f"yazdir_{item.id}"):
            st.session_state.pdf_bytes = pdf_bytes([item])
            st.session_state.pdf_name = f"etiket_{safe(item.tracking_number or item.barcode)}.pdf"
            item.is_printed = True
            db.commit()
            st.rerun()

    with c8:
        if st.button("Sil", key=f"sil_{item.id}"):
            db.delete(item)
            db.commit()
            if item.id in st.session_state.selected_shipments:
                st.session_state.selected_shipments.remove(item.id)
            st.rerun()

    if st.session_state.get(f"show_{item.id}", False):
        with st.expander("Gönderi Detayı / Düzenle", expanded=True):
            with st.form(f"edit_form_{item.id}"):
                e1, e2 = st.columns(2)

                with e1:
                    new_recipient = st.text_input("Alıcı Adı", value=safe(item.recipient_name))
                    new_address = st.text_area("Adres", value=safe(item.address))
                    new_district = st.text_input("İlçe", value=safe(item.district))
                    new_city = st.text_input("İl", value=safe(item.city))
                    new_phone = st.text_input("Telefon", value=safe(item.phone))

                with e2:
                    new_branch_code = st.text_input("Şube Kodu", value=safe(item.branch_code))
                    new_branch_name = st.text_input("Şube Adı", value=safe(item.branch_name))
                    new_product = st.text_input("Ürün İçeriği", value=safe(item.product_name))
                    new_width = st.number_input("En", value=float(item.width or 0), key=f"w_{item.id}")
                    new_length = st.number_input("Boy", value=float(item.length or 0), key=f"l_{item.id}")
                    new_height = st.number_input("Yükseklik", value=float(item.height or 0), key=f"h_{item.id}")
                    new_weight = st.number_input("Ağırlık", value=float(item.weight or 0), key=f"a_{item.id}")

                saved = st.form_submit_button("Düzenlemeyi Kaydet")

                if saved:
                    item.recipient_name = new_recipient
                    item.address = new_address
                    item.district = new_district
                    item.city = new_city
                    item.phone = new_phone
                    item.branch_code = new_branch_code
                    item.branch_name = new_branch_name
                    item.product_name = new_product
                    item.width = new_width
                    item.length = new_length
                    item.height = new_height
                    item.weight = new_weight
                    item.is_printed = False
                    db.commit()
                    st.success("Gönderi güncellendi. Yeniden yazdırılmalı.")
                    st.rerun()

st.divider()

selected = get_selected_shipments()
st.write(f"Seçilen Kayıt: {len(selected)}")

b1, b2, b3 = st.columns(3)

with b1:
    if st.button("Seçilenleri Yazdır", use_container_width=True):
        if not selected:
            st.warning("Seçili gönderi yok.")
        else:
            st.session_state.pdf_bytes = pdf_bytes(selected)
            st.session_state.pdf_name = f"etiketler_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
            for item in selected:
                item.is_printed = True
            db.commit()
            st.rerun()

with b2:
    if selected:
        st.download_button(
            "Seçilenleri Excele Aktar",
            data=excel_bytes(selected),
            file_name=f"gonderiler_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True,
        )
    else:
        st.button("Seçilenleri Excele Aktar", disabled=True, use_container_width=True)

with b3:
    if st.button("Seçilenleri Sil", use_container_width=True):
        if not selected:
            st.warning("Seçili gönderi yok.")
        else:
            for item in selected:
                db.delete(item)
            db.commit()
            st.session_state.selected_shipments = []
            st.rerun()

if st.session_state.pdf_bytes:
    st.download_button(
        "PDF İndir",
        data=st.session_state.pdf_bytes,
        file_name=st.session_state.pdf_name,
        mime="application/pdf",
        use_container_width=True,
    )
