import streamlit as st
import pandas as pd

from database.database import SessionLocal, engine
from database.models import Base, Branch, ProductDimension, Barcode, Shipment

Base.metadata.create_all(bind=engine)

st.title("Gönderi Oluştur")

db = SessionLocal()

if "sepet" not in st.session_state:
    st.session_state.sepet = []


def clean(value):
    return str(value or "").strip()


def norm(value):
    return clean(value).lower()


def get_product_dimension(product_name):
    product_name_norm = norm(product_name)
    if not product_name_norm:
        return None

    products = db.query(ProductDimension).all()
    for product in products:
        if norm(product.product_name) == product_name_norm:
            return product
    return None


def available_barcodes(count):
    cart_barcodes = {item["barcode"] for item in st.session_state.sepet}
    all_barcodes = db.query(Barcode).filter(Barcode.is_used == False).all()
    result = []

    for barcode in all_barcodes:
        if barcode.barcode not in cart_barcodes:
            result.append(barcode)
        if len(result) == count:
            break

    return result


def branch_suggestions(code_query, name_query):
    code_query = norm(code_query)
    name_query = norm(name_query)

    branches = db.query(Branch).order_by(Branch.branch_code).all()
    result = []

    for branch in branches:
        code_match = code_query and code_query in norm(branch.branch_code)
        name_match = name_query and name_query in norm(branch.branch_name)

        if code_match or name_match:
            result.append(branch)

    return result


st.subheader("Şube / Alıcı Bilgileri")

col_code, col_name = st.columns(2)

with col_code:
    branch_code_search = st.text_input("Şube Kodu")

with col_name:
    branch_name_search = st.text_input("Şube Adı")

selected_branch = None

if clean(branch_code_search) == "0000":
    st.info("0000 manuel gönderi. Alıcı bilgilerini elle doldurun.")
else:
    suggestions = branch_suggestions(branch_code_search, branch_name_search)

    if suggestions:
        options = [
            f"{branch.branch_code} - {branch.branch_name}"
            for branch in suggestions
        ]

        selected_label = st.selectbox(
            "Bulunan Şubeler",
            options
        )

        selected_index = options.index(selected_label)
        selected_branch = suggestions[selected_index]

        st.success(
            f"Seçilen: {selected_branch.branch_code} - {selected_branch.branch_name}"
        )
    elif branch_code_search or branch_name_search:
        st.warning("Şube bulunamadı. Manuel bilgiyle devam edebilirsiniz.")

if selected_branch:
    default_branch_code = selected_branch.branch_code or ""
    default_branch_name = selected_branch.branch_name or ""
    default_recipient = selected_branch.branch_name or ""
    default_address = selected_branch.address or ""
    default_district = selected_branch.district or ""
    default_city = selected_branch.city or ""
else:
    default_branch_code = clean(branch_code_search)
    default_branch_name = clean(branch_name_search)
    default_recipient = clean(branch_name_search)
    default_address = ""
    default_district = ""
    default_city = ""

col1, col2 = st.columns(2)

with col1:
    recipient_name = st.text_input(
        "Alıcı Adı",
        value=default_recipient,
        key=f"recipient_{default_branch_code}_{default_branch_name}"
    )

    recipient_phone = st.text_input("Telefon")

with col2:
    recipient_district = st.text_input(
        "İlçe",
        value=default_district,
        key=f"district_{default_branch_code}_{default_branch_name}"
    )

    recipient_city = st.text_input(
        "İl",
        value=default_city,
        key=f"city_{default_branch_code}_{default_branch_name}"
    )

recipient_address = st.text_area(
    "Adres",
    value=default_address,
    key=f"address_{default_branch_code}_{default_branch_name}"
)

st.divider()

st.subheader("Ürün Bilgileri")

product_name = st.text_input("Ürün İçeriği")

product_dimension = get_product_dimension(product_name)

if product_dimension:
    st.success("Ürün ölçüsü bulundu ve otomatik dolduruldu.")
    default_width = float(product_dimension.width or 0)
    default_length = float(product_dimension.length or 0)
    default_height = float(product_dimension.height or 0)
    default_weight = float(product_dimension.weight or 0)
else:
    default_width = 0.0
    default_length = 0.0
    default_height = 0.0
    default_weight = 0.0

col1, col2, col3, col4, col5 = st.columns(5)

with col1:
    width = st.number_input("En", min_value=0.0, value=default_width, step=1.0)

with col2:
    length = st.number_input("Boy", min_value=0.0, value=default_length, step=1.0)

with col3:
    height = st.number_input("Yükseklik", min_value=0.0, value=default_height, step=1.0)

with col4:
    weight = st.number_input("Ağırlık (gr)", min_value=0.0, value=default_weight, step=1.0)

with col5:
    quantity = st.number_input("Adet", min_value=1, value=1, step=1)

if st.button("Sepete Ekle", use_container_width=True):
    if not clean(recipient_name):
        st.error("Alıcı adı boş olamaz.")
    elif not clean(product_name):
        st.error("Ürün içeriği boş olamaz.")
    else:
        barcodes = available_barcodes(int(quantity))

        if len(barcodes) < int(quantity):
            st.error(
                f"Yetersiz barkod. İstenen: {quantity}, Kullanılabilir: {len(barcodes)}"
            )
        else:
            for barcode in barcodes:
                st.session_state.sepet.append(
                    {
                        "barcode": barcode.barcode,
                        "tracking_number": barcode.barcode,
                        "branch_code": default_branch_code,
                        "branch_name": default_branch_name,
                        "recipient_name": recipient_name,
                        "address": recipient_address,
                        "district": recipient_district,
                        "city": recipient_city,
                        "phone": recipient_phone,
                        "product_name": product_name,
                        "width": width,
                        "length": length,
                        "height": height,
                        "weight": weight,
                    }
                )

            st.success(f"{quantity} gönderi sepete eklendi.")
            st.rerun()

st.divider()

st.subheader(f"Sepet ({len(st.session_state.sepet)})")

if not st.session_state.sepet:
    st.info("Sepet boş.")
else:
    grouped = {}

    for item in st.session_state.sepet:
        recipient = item.get("recipient_name") or "Alıcı Yok"
        grouped.setdefault(recipient, []).append(item)

    for recipient, records in grouped.items():
        with st.expander(f"{recipient} ({len(records)} gönderi)", expanded=True):
            for item in records:
                real_index = st.session_state.sepet.index(item)

                col1, col2, col3 = st.columns([8, 2, 1])

                with col1:
                    st.write(
                        f"{item['barcode']} | "
                        f"{item['product_name']} | "
                        f"{item['width']}x{item['length']}x{item['height']} | "
                        f"{item['weight']} gr"
                    )

                with col2:
                    if st.button("Düzenle", key=f"cart_edit_{real_index}"):
                        st.session_state[f"cart_edit_open_{real_index}"] = not st.session_state.get(
                            f"cart_edit_open_{real_index}", False
                        )
                        st.rerun()

                with col3:
                    if st.button("❌", key=f"cart_delete_{real_index}"):
                        st.session_state.sepet.pop(real_index)
                        st.rerun()

                if st.session_state.get(f"cart_edit_open_{real_index}", False):
                    e1, e2, e3, e4, e5 = st.columns(5)

                    with e1:
                        new_product = st.text_input(
                            "Ürün",
                            value=item["product_name"],
                            key=f"cart_product_{real_index}"
                        )

                    with e2:
                        new_width = st.number_input(
                            "En",
                            value=float(item["width"]),
                            key=f"cart_width_{real_index}"
                        )

                    with e3:
                        new_length = st.number_input(
                            "Boy",
                            value=float(item["length"]),
                            key=f"cart_length_{real_index}"
                        )

                    with e4:
                        new_height = st.number_input(
                            "Yükseklik",
                            value=float(item["height"]),
                            key=f"cart_height_{real_index}"
                        )

                    with e5:
                        new_weight = st.number_input(
                            "Ağırlık",
                            value=float(item["weight"]),
                            key=f"cart_weight_{real_index}"
                        )

                    if st.button("Düzenlemeyi Kaydet", key=f"cart_save_{real_index}"):
                        st.session_state.sepet[real_index]["product_name"] = new_product
                        st.session_state.sepet[real_index]["width"] = new_width
                        st.session_state.sepet[real_index]["length"] = new_length
                        st.session_state.sepet[real_index]["height"] = new_height
                        st.session_state.sepet[real_index]["weight"] = new_weight
                        st.session_state[f"cart_edit_open_{real_index}"] = False
                        st.rerun()

    st.divider()

    col1, col2 = st.columns(2)

    with col1:
        if st.button("Sepeti Temizle", use_container_width=True):
            st.session_state.sepet = []
            st.rerun()

    with col2:
        if st.button("Gönderileri Kaydet", use_container_width=True):
            for item in st.session_state.sepet:
                shipment = Shipment(
                    barcode=item["barcode"],
                    tracking_number=item["tracking_number"],
                    branch_code=item["branch_code"],
                    branch_name=item["branch_name"],
                    recipient_name=item["recipient_name"],
                    address=item["address"],
                    district=item["district"],
                    city=item["city"],
                    phone=item["phone"],
                    product_name=item["product_name"],
                    width=item["width"],
                    length=item["length"],
                    height=item["height"],
                    weight=item["weight"],
                    created_by="admin",
                    is_printed=False,
                )

                db.add(shipment)

                barcode = (
                    db.query(Barcode)
                    .filter(Barcode.barcode == item["barcode"])
                    .first()
                )

                if barcode:
                    barcode.is_used = True

            db.commit()
            st.session_state.sepet = []
            st.success("Gönderiler kaydedildi.")
            st.rerun()
