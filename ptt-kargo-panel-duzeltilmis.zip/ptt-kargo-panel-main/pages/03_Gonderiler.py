import io
from datetime import datetime

import pandas as pd
import streamlit as st
from reportlab.graphics.barcode import code128
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas

from database.database import SessionLocal, engine
from database.models import Base, Shipment

Base.metadata.create_all(bind=engine)

st.title("Gönderiler")

db = SessionLocal()

if "selected_shipments" not in st.session_state:
    st.session_state.selected_shipments = []

if "pdf_bytes" not in st.session_state:
    st.session_state.pdf_bytes = None

if "pdf_name" not in st.session_state:
    st.session_state.pdf_name = "etiketler.pdf"


def safe_text(value):
    text = str(value or "")
    replacements = {
        "İ": "I", "ı": "i", "Ş": "S", "ş": "s", "Ğ": "G", "ğ": "g",
        "Ü": "U", "ü": "u", "Ö": "O", "ö": "o", "Ç": "C", "ç": "c",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text


def short_text(value, limit):
    text = safe_text(value)
    if len(text) <= limit:
        return text
    return text[:limit - 2] + ".."


def draw_label(c, item):
    width, height = 40 * mm, 50 * mm

    c.setLineWidth(0.4)
    c.rect(1 * mm, 1 * mm, width - 2 * mm, height - 2 * mm)

    c.setFont("Helvetica-Bold", 5.8)
    c.drawCentredString(width / 2, 47 * mm, "PTT GENEL MUDURLUGU")
    c.drawCentredString(width / 2, 44.7 * mm, "KARGO ETIKETI")

    c.rect(1 * mm, 37.5 * mm, 24 * mm, 6 * mm)
    c.rect(25 * mm, 37.5 * mm, 14 * mm, 6 * mm)

    c.setFont("Helvetica-Bold", 3.8)
    c.drawString(2 * mm, 41.2 * mm, "GONDERICI")
    c.setFont("Helvetica", 3.4)
    c.drawString(2 * mm, 39.4 * mm, "ZIRAAT KATILIM")
    c.drawString(2 * mm, 37.9 * mm, "HADIMKOY LOJ.")

    c.setFont("Helvetica-Bold", 3.6)
    c.drawString(26 * mm, 41.1 * mm, "PTT KABUL")
    c.drawString(26 * mm, 39.4 * mm, "MERKEZI")

    c.rect(1 * mm, 27 * mm, 38 * mm, 10 * mm)
    c.setFont("Helvetica-Bold", 3.8)
    c.drawString(2 * mm, 35.2 * mm, "ALICI")
    c.setFont("Helvetica-Bold", 4.2)
    c.drawString(2 * mm, 33.2 * mm, short_text(item.recipient_name, 34))
    c.setFont("Helvetica", 3.6)
    c.drawString(2 * mm, 31.2 * mm, short_text(item.address, 42))
    c.drawString(2 * mm, 29.3 * mm, short_text(f"{item.district} / {item.city}", 42))

    c.rect(1 * mm, 21 * mm, 9.5 * mm, 6 * mm)
    c.rect(10.5 * mm, 21 * mm, 10 * mm, 6 * mm)
    c.rect(20.5 * mm, 21 * mm, 9 * mm, 6 * mm)
    c.rect(29.5 * mm, 21 * mm, 9.5 * mm, 6 * mm)

    c.setFont("Helvetica-Bold", 3.2)
    c.drawString(2 * mm, 25.2 * mm, "TARIH")
    c.drawString(11.3 * mm, 25.2 * mm, "OLCU")
    c.drawString(21.3 * mm, 25.2 * mm, "GR")
    c.drawString(30.3 * mm, 25.2 * mm, "SUBE")

    c.setFont("Helvetica", 3.2)
    c.drawString(2 * mm, 22.8 * mm, datetime.now().strftime("%d.%m"))
    c.drawString(11.3 * mm, 22.8 * mm, short_text(f"{item.width}x{item.length}x{item.height}", 10))
    c.drawString(21.3 * mm, 22.8 * mm, short_text(item.weight, 7))
    c.drawString(30.3 * mm, 22.8 * mm, short_text(item.branch_code, 7))

    c.rect(1 * mm, 16 * mm, 38 * mm, 5 * mm)
    c.setFont("Helvetica-Bold", 3.3)
    c.drawString(2 * mm, 19.2 * mm, "URUN ICERIGI")
    c.setFont("Helvetica-Bold", 4.4)
    c.drawString(2 * mm, 17.2 * mm, short_text(item.product_name, 36))

    barcode_value = safe_text(item.tracking_number or item.barcode)
    barcode = code128.Code128(barcode_value, barHeight=7 * mm, barWidth=0.28 * mm)
    barcode.drawOn(c, 4 * mm, 6.5 * mm)

    c.setFont("Helvetica-Bold", 5.0)
    c.drawCentredString(width / 2, 3.5 * mm, barcode_value)


def create_pdf(shipments):
    buffer = io.BytesIO()
    page_size = (40 * mm, 50 * mm)
    c = canvas.Canvas(buffer, pagesize=page_size)

    for shipment in shipments:
        draw_label(c, shipment)
        c.showPage()

    c.save()
    buffer.seek(0)
    return buffer.getvalue()


def excel_bytes(shipments):
    rows = []

    for item in shipments:
        rows.append({
            "A": "",
            "B": item.recipient_name,
            "C": item.address,
            "D": item.district,
            "E": item.city,
            "F": item.weight,
            "G": item.phone,
            "H": "",
            "I": item.product_name,
            "J": "",
            "K": "",
            "L": item.tracking_number,
            "M": "",
            "N": "",
            "O": "",
            "P": "",
            "Q": "",
            "R": "",
            "S": item.width,
            "T": item.length,
            "U": item.height,
        })

    output = io.BytesIO()
    pd.DataFrame(rows).to_excel(output, index=False)
    output.seek(0)
    return output.getvalue()


def selected_items():
    if not st.session_state.selected_shipments:
        return []

    return (
        db.query(Shipment)
        .filter(Shipment.id.in_(st.session_state.selected_shipments))
        .order_by(Shipment.id.asc())
        .all()
    )


col1, col2, col3, col4 = st.columns(4)

with col1:
    filter_status = st.selectbox("Durum", ["Tümü", "Yazdırılmadı", "Yazdırıldı"])

with col2:
    filter_recipient = st.text_input("Alıcı Adı")

with col3:
    filter_product = st.text_input("Ürün İçeriği")

with col4:
    filter_tracking = st.text_input("Takip No")

filter_user = st.text_input("Kullanıcı Adı")

shipments = db.query(Shipment).order_by(Shipment.id.desc()).all()

filtered = []
for item in shipments:
    if filter_status == "Yazdırılmadı" and item.is_printed:
        continue
    if filter_status == "Yazdırıldı" and not item.is_printed:
        continue
    if filter_recipient and filter_recipient.lower() not in str(item.recipient_name or "").lower():
        continue
    if filter_product and filter_product.lower() not in str(item.product_name or "").lower():
        continue
    if filter_tracking and filter_tracking.lower() not in str(item.tracking_number or "").lower():
        continue
    if filter_user and filter_user.lower() not in str(item.created_by or "").lower():
        continue
    filtered.append(item)

st.write(f"Toplam Kayıt: {len(filtered)}")

col_select, col_print, col_excel, col_delete = st.columns(4)

with col_select:
    if st.button("Tümünü Seç", use_container_width=True):
        st.session_state.selected_shipments = [item.id for item in filtered]
        st.rerun()

with col_print:
    if st.button("Seçilenleri Yazdır", use_container_width=True):
        items = selected_items()
        if not items:
            st.error("Seçili gönderi yok.")
        else:
            st.session_state.pdf_bytes = create_pdf(items)
            st.session_state.pdf_name = f"etiketler_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"

            for item in items:
                item.is_printed = True

            db.commit()
            st.success(f"{len(items)} etiket PDF olarak hazırlandı.")

with col_excel:
    items = selected_items()
    if items:
        st.download_button(
            "Seçilenleri Excele Aktar",
            data=excel_bytes(items),
            file_name="gonderiler.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True,
        )
    else:
        st.button("Seçilenleri Excele Aktar", disabled=True, use_container_width=True)

with col_delete:
    if st.button("Seçilenleri Sil", use_container_width=True):
        items = selected_items()
        for item in items:
            db.delete(item)
        db.commit()
        st.session_state.selected_shipments = []
        st.rerun()

if st.session_state.pdf_bytes:
    st.download_button(
        "PDF İndir",
        data=st.session_state.pdf_bytes,
        file_name=st.session_state.pdf_name,
        mime="application/pdf",
        use_container_width=True,
    )

st.divider()

header = st.columns([1, 2, 3, 3, 3, 2, 2, 2, 2])
header[0].markdown("**Seç**")
header[1].markdown("**Durum**")
header[2].markdown("**Alıcı Adı**")
header[3].markdown("**Ürün İçeriği**")
header[4].markdown("**Takip No**")
header[5].markdown("**Kullanıcı**")
header[6].markdown("**Düzenle**")
header[7].markdown("**Yazdır**")
header[8].markdown("**Sil**")

for item in filtered:
    row = st.columns([1, 2, 3, 3, 3, 2, 2, 2, 2])

    with row[0]:
        checked = st.checkbox(
            "",
            value=item.id in st.session_state.selected_shipments,
            key=f"select_{item.id}",
        )
        if checked and item.id not in st.session_state.selected_shipments:
            st.session_state.selected_shipments.append(item.id)
        if not checked and item.id in st.session_state.selected_shipments:
            st.session_state.selected_shipments.remove(item.id)

    with row[1]:
        if item.is_printed:
            st.error("Yazdırıldı")
        else:
            st.success("Yazdırılmadı")

    row[2].write(item.recipient_name)
    row[3].write(item.product_name)
    row[4].write(item.tracking_number)
    row[5].write(item.created_by)

    with row[6]:
        if st.button("Düzenle", key=f"edit_{item.id}"):
            st.session_state[f"edit_open_{item.id}"] = not st.session_state.get(f"edit_open_{item.id}", False)
            st.rerun()

    with row[7]:
        if st.button("Yazdır", key=f"print_{item.id}"):
            st.session_state.pdf_bytes = create_pdf([item])
            st.session_state.pdf_name = f"etiket_{item.tracking_number}.pdf"
            item.is_printed = True
            db.commit()
            st.success("PDF hazırlandı.")

    with row[8]:
        if st.button("Sil", key=f"delete_{item.id}"):
            db.delete(item)
            db.commit()
            st.rerun()

    if st.session_state.get(f"edit_open_{item.id}", False):
        with st.expander(f"Detay / Düzenle - {item.tracking_number}", expanded=True):
            c1, c2 = st.columns(2)

            with c1:
                new_recipient = st.text_input("Alıcı Adı", value=item.recipient_name or "", key=f"recipient_{item.id}")
                new_address = st.text_area("Adres", value=item.address or "", key=f"address_{item.id}")
                new_district = st.text_input("İlçe", value=item.district or "", key=f"district_{item.id}")
                new_city = st.text_input("İl", value=item.city or "", key=f"city_{item.id}")
                new_phone = st.text_input("Telefon", value=item.phone or "", key=f"phone_{item.id}")

            with c2:
                new_product = st.text_input("Ürün İçeriği", value=item.product_name or "", key=f"product_{item.id}")
                new_width = st.number_input("En", value=float(item.width or 0), key=f"width_{item.id}")
                new_length = st.number_input("Boy", value=float(item.length or 0), key=f"length_{item.id}")
                new_height = st.number_input("Yükseklik", value=float(item.height or 0), key=f"height_{item.id}")
                new_weight = st.number_input("Ağırlık", value=float(item.weight or 0), key=f"weight_{item.id}")

            if st.button("Kaydet", key=f"save_{item.id}"):
                item.recipient_name = new_recipient
                item.address = new_address
                item.district = new_district
                item.city = new_city
                item.phone = new_phone
                item.product_name = new_product
                item.width = new_width
                item.length = new_length
                item.height = new_height
                item.weight = new_weight

                if item.is_printed:
                    item.is_printed = False

                db.commit()
                st.session_state[f"edit_open_{item.id}"] = False
                st.rerun()
